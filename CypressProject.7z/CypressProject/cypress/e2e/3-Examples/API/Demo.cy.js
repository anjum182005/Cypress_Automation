describe('API automation',function()
{

    it('GET', function(){
        cy.visit("https://httpbin.org/");
        cy.get('title').should('have.text','httpbin.org')


        cy.request({            
            method: "GET", 
            url: "https://httpbin.org/get",
                       
        }).as('getResponse');

        cy.get('@getResponse').then(response => {
            expect(response.status).to.eq(200);
            cy.log(JSON.stringify(response.body));

             });

    });

    it('GET', function(){

        cy.request({            
            method: "GET", 
            url: "https://gorest.co.in/public/v2/users",
                       
        }).as('getResponseList');

        cy.get('@getResponseList').then(response1 => {
            expect(response1.status).to.eq(200);
            cy.log(JSON.stringify(response1.body));
          //  expect(response1.body[0].id ).to.eq(2369);
          //  expect(response1.body[0].name).to.eq("Bilwa Kaul");
            

             });

    });


    it('POSTRequest', () => {

        cy.request({            
            method: "POST", 
            url: "https://httpbin.org/post",
            body: {
                "args": {},
                "data": "",
                "files": {},
                "form": {},
                "headers": {
                  "Accept": "application/json",
                  "Accept-Encoding": "gzip, deflate, br",
                  "Accept-Language": "en-US,en;q=0.9",
                  "Content-Length": "0",
                  "Host": "httpbin.org",
                  "Origin": "https://httpbin.org",
                  "Referer": "https://httpbin.org/",
                  "Sec-Ch-Ua": "\"Chromium\";v=\"106\", \"Google Chrome\";v=\"106\", \"Not;A=Brand\";v=\"99\"",
                  "Sec-Ch-Ua-Mobile": "?0",
                  "Sec-Ch-Ua-Platform": "\"Windows\"",
                  "Sec-Fetch-Dest": "empty",
                  "Sec-Fetch-Mode": "cors",
                  "Sec-Fetch-Site": "same-origin",
                  "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36",
                  "X-Amzn-Trace-Id": "Root=1-633c0904-5334d7b81c617eb66d143eaf"
                },
                "json": null,
                "origin": "103.207.8.136",
                "url": "https://httpbin.org/post"
              }
                       
        }).as('postResponse');

        cy.get('@postResponse').then(response2 => {
            expect(response2.status).to.eq(200);
            

             });

    });
});