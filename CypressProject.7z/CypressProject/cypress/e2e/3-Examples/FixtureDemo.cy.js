import LoginPage from "./PageObejct/Loginpage";

describe('Test Suite', function(){

        before(function() {
            // runs once before all tests in the it block  
        cy.log("I am in before")
        cy.fixture('example').then((user)=>{ 
            this.user=user
        })
    })

    it('FixtureDataDemo', function(){
        const lp=new LoginPage
        lp.visit()
        lp.fillEmail('anjum182005@gmail.com')
        lp.fillPassword('Test@1234')
        lp.submit()
        //const pgtitle=cy.get('.page-title')
        cy.get('.page-title').should('have.text','Welcome, Please Sign In!')


    })

    it('FixtureDataDemo_withfixture', function(){
        const lp=new LoginPage
       cy.fixture('example').then((user)=>{           
        
        lp.visit()
        cy.get('input[name=Email]').type(user.email)
        cy.get('input[name=Password]').type(user.password)
        lp.submit()
        //const pgtitle=cy.get('.page-title')
        cy.get('.page-title').should('have.text','Welcome, Please Sign In!')
    })

    })

})
