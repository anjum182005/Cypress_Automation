describe('My First Test', function()
{
    it('Verify Title og page', function() {
        
      cy.visit('https://demo.nopcommerce.com/')
      cy.title().should('eq','nopCommerce demo store')
      //cy.contains('type').click()
    })
})