class RegisterPage
{
    Register(){
            
          cy.visit('https://demo.nopcommerce.com/');
          cy.contains('Register').click()
          
          cy.get('#gender-female').click()
          cy.get('#FirstName').type('Anjuman')
          cy.get('#LastName').type('Nadaf')
          cy.wait(1000)  
          cy.get('[name="DateOfBirthDay"]').select('18')
         
          cy.get('[name="DateOfBirthMonth"]').select('March')
          cy.get('[name="DateOfBirthYear"]').select('2000')
          cy.get('#Email').type('anjum182005@gmail.com')
          cy.get('#Company').type('TSYS')
          cy.get('#Password').type('Test@1234') 
          cy.get('#ConfirmPassword').type('Test@1234')
          cy.get('#register-button').click
          cy.get('[id="register-button"]').click()
          cy.on('.message-error validation-summary-errors', (text) => {
            expect(text).to.contains('The specified email already 1');
            return false
          });
               
      }
    }

export default RegisterPage
